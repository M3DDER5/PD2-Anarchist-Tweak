Hooks:PostHook(UpgradesTweakData, "_init_pd2_values", "anarchy", function(self)
	
	--Armor Regen--
	self.values.player.armor_grinding = {{
		{0.1,0.1},
		{7.5,2},
		{12,6},
		{15,7},
		{18,8},
		{20,9},
		{25,10}
	}}

	--Invulnerability--
	self.values.temporary.armor_break_invulnerable = {
		{4,8}
	}

	--Health To Armor--
	self.values.player.health_decrease = {
		0.5
	}
	self.values.player.armor_increase = {
		1,
		1.1,
		1.5
	}

	--Armor Regen When Damage--
	self.values.player.damage_to_armor = {
		{
			{0.5,0},
			{7.5,0.5},
			{10,1.0},
			{12.5,1.5},
			{15,2.5},
			{20,3.0},
			{25,5.0}
		}
	}
end)