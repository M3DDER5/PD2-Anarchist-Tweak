Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_LocExample", function(loc)

	loc:add_localized_strings( {
		--PERKS
		--Anarchist
		["menu_deck15_1_desc"] = "Instead of fully regenerating armor when out of combat, The Anarchist will continuously regenerate armor throughout the entire combat. Heavier armor regenerates more armor, but during longer intervals.\nWhen your armor gets depleted, you will be immune to health damage for ##4## seconds. This effect cannot occur more often than once every ##8## seconds.\nNote: Skills and perks that increases the armor recovery rate are disabled when using this perk deck. ",
		["menu_deck15_3_desc"] = "##50%## of your health is converted into ##100%## armor. ",
		["menu_deck15_5_desc"] = "##50%## of your health is converted into ##120%## armor. ",
		["menu_deck15_7_desc"] = "##50%## of your health is converted into ##150%## armor. ",
		["menu_deck15_9_desc"] = "Dealing damage will grant you armor relative to what armor is equipped:\n\nTwo-Piece Suit - ##5## Armor, every hit\nLight Ballistic Vest - ##75## Armor, once every ##0.5## seconds\nBallistic Vest - ##100## Armor, once every ##1## second\nHeavy Ballistic Vest - ##125## Armor, once every ##1.5## seconds\nFlak Jacket - ##150## Armor, once every ##2.5## seconds\nCTV - ##200## Armor, once every ##3## seconds\nICTV - ##250## Armor, once every ##5## seconds\n\nDeck Completion Bonus: Your chance of getting a higher quality item during a PAYDAY is increased by ##10%##."
	} )
end)